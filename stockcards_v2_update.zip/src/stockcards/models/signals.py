"""
Data models for stock signals and market data.

These are Pydantic models — they define the SHAPE of data flowing
through the system. Think of them as a contract:
  "A StockSignal will ALWAYS have these fields, with these types."

If any field is wrong type or missing, Pydantic raises an error
before it reaches your frontend. No more debugging "undefined" in JS.
"""

from pydantic import BaseModel, Field
from typing import Optional


class StockSignal(BaseModel):
    """Complete analysis result for a single stock.

    This is what the frontend receives for each card in the dashboard.
    Every field maps to something visible in the UI.
    """

    # Identity
    ticker: str = Field(..., description="Stock ticker symbol, e.g. AAPL")
    name: str = Field(..., max_length=30, description="Company short name")

    # Price
    price: float = Field(..., description="Current price in USD")
    change: float = Field(..., description="Daily % change")

    # Signal
    signal: str = Field(..., description="BREAKOUT | BUY | READY | WATCH | WAIT | AVOID")
    confidence: int = Field(..., ge=0, le=100, description="Signal confidence 0-100")

    # Technical indicators
    rsi: float = Field(default=50.0, description="Relative Strength Index (14-period)")
    distance_from_ath: float = Field(default=100.0, description="% below all-time high")
    pole_move: float = Field(default=0.0, description="% move in pole (flag pattern)")
    flag_range: float = Field(default=100.0, description="% range of flag consolidation")
    has_flag: bool = Field(default=False, description="Flag pattern detected?")
    uptrend: bool = Field(default=False, description="Price > SMA20 > SMA50?")
    near_ath: bool = Field(default=False, description="Within 20% of ATH?")

    # Institutional metrics
    relative_strength: float = Field(default=1.0, description="Performance vs S&P500 (>1 = outperforming)")
    volume_surge: bool = Field(default=False, description="Volume > 150% of 20-day avg?")
    avg_volume: int = Field(default=0, description="20-day average volume")
    today_volume: int = Field(default=0, description="Today's volume")

    # Risk management
    stop_loss: float = Field(default=0.0, description="Suggested stop loss price")
    position_size: int = Field(default=0, description="Suggested shares (based on portfolio settings)")

    # Human-readable
    summary: str = Field(default="", description="One-line signal summary")
    explanation: str = Field(default="", description="Detailed explanation")
    risk: str = Field(default="Medium", description="Risk level label")
    potential: str = Field(default="10-15%", description="Upside potential range")
    timeframe: str = Field(default="2-4 weeks", description="Expected timeframe")


class MarketMood(BaseModel):
    """Single market fear/greed reading."""

    value: int = Field(..., ge=0, le=100, description="Fear (0) to Greed (100)")
    label: str = Field(..., description="Human label, e.g. 'Extreme Fear'")
    recommendation: str = Field(..., description="Action suggestion based on mood")
    source: str = Field(..., description="Data source, e.g. 'CNN Fear & Greed'")


class DualMarketMood(BaseModel):
    """Both stock and crypto fear/greed — shown side by side in the UI."""

    stocks: MarketMood
    crypto: MarketMood


class NewsItem(BaseModel):
    """Single news article."""

    title: str
    summary: str = Field(default="", max_length=200)
    link: str = Field(default="#")
    source: str = Field(default="Unknown")
    date: str = Field(default="Recent")
    related_tickers: list[str] = Field(default_factory=list)


class DashboardData(BaseModel):
    """Full dashboard response — everything the frontend needs in one call."""

    market_mood: DualMarketMood
    stocks: list[StockSignal]
    news: list[NewsItem]
    last_updated: str
