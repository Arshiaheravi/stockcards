"""
Stock screener — finds opportunities across the entire market.

Instead of scanning 15 hardcoded tickers, this screens ~8,000 stocks
using Finviz filters to find the ones that ALREADY match our criteria:
    - Near 52-week highs (within 20%)
    - Above SMA20 and SMA50 (uptrend)
    - Good volume (>500K avg daily)
    - Price > $10 (no penny stocks)
    - Market cap > $2B (liquid, institutional interest)

Then the dashboard runs full technical analysis on just these candidates.
This turns a 15-stock scan into a 40-80 stock scan of PRE-QUALIFIED names.

USAGE:
    tickers = get_screened_tickers()  # Returns ~40-80 tickers
    # Then analyze each one with full pipeline
"""

import logging
import time
from typing import Optional

logger = logging.getLogger(__name__)

# Cache screener results in memory (refreshes every 4 hours)
_cache: dict = {"tickers": [], "timestamp": 0, "ttl": 14400}

# Fallback universe — broad market leaders + growth + momentum names
# This is used if finviz screening fails
FALLBACK_UNIVERSE = [
    # Mega-cap tech
    "AAPL", "MSFT", "NVDA", "GOOGL", "AMZN", "META", "TSLA", "AVGO", "ORCL", "CRM",
    # Semiconductors
    "AMD", "MRVL", "ANET", "KLAC", "LRCX", "ASML", "MU", "QCOM", "MCHP", "ON",
    # Software/Cloud
    "PLTR", "CRWD", "PANW", "NOW", "SNOW", "DDOG", "ZS", "FTNT", "WDAY", "TTD",
    # Financials
    "JPM", "GS", "MS", "V", "MA", "AXP", "BLK", "SCHW", "CME", "ICE",
    # Healthcare
    "LLY", "UNH", "ISRG", "VRTX", "REGN", "ABBV", "TMO", "DHR", "BSX", "EW",
    # Industrials/Defense
    "LMT", "GE", "RTX", "NOC", "GD", "HWM", "TDG", "PH", "EMR", "ETN",
    # Consumer
    "COST", "WMT", "NKE", "SBUX", "MCD", "TJX", "LULU", "DPZ", "CMG", "DECK",
    # Energy/Materials
    "XOM", "CVX", "SLB", "FCX", "NEM", "FSLR", "ENPH", "CEG", "VST", "NRG",
    # Mid-cap momentum (where the real opportunities are)
    "SN", "CART", "TOST", "DUOL", "CAVA", "WING", "BROS", "DKNG", "PINS", "RBLX",
    "APP", "SHOP", "HUBS", "MNDY", "CELH", "ELF", "ONON", "BIRK", "TXRH", "COKE",
    # Recently hot / IPOs
    "ARM", "SMCI", "VRT", "GEV", "HOOD", "RDDT", "PSN", "AXON", "CVNA", "IBKR",
    # International ADRs
    "TSM", "NVO", "SAP", "MELI", "NU", "SE", "GRAB", "BABA", "JD", "PDD",
]


def _screen_finviz() -> list[str]:
    """Use finvizfinance to screen for stocks matching our criteria.
    
    Filters:
        - Market cap > $2B (Mid-cap+)
        - Price > $10
        - Average volume > 500K
        - 52-week high within 20% of current
        - Above SMA20 and SMA50
        - Positive EPS growth
    """
    try:
        from finvizfinance.screener.overview import Overview
        
        screener = Overview()
        filters = {
            "Market Cap.": "+Mid (over $2bln)",
            "Price": "Over $10",
            "Average Volume": "Over 500K",
            "52-Week High/Low": "0-20% below High",
            "20-Day Simple Moving Average": "Price above SMA20",
            "50-Day Simple Moving Average": "Price above SMA50",
        }
        
        screener.set_filter(filters_dict=filters)
        df = screener.screener_view()
        
        if df is not None and not df.empty:
            tickers = df["Ticker"].tolist()
            logger.info("Finviz screener found %d candidates", len(tickers))
            return tickers[:80]  # Cap at 80 to keep scan time reasonable
        
        logger.warning("Finviz screener returned empty results")
        return []
        
    except ImportError:
        logger.warning("finvizfinance not installed, using fallback universe")
        return []
    except Exception as e:
        logger.warning("Finviz screener failed: %s, using fallback", e)
        return []


def _screen_yfinance_sp500() -> list[str]:
    """Fallback: screen S&P500 + growth stocks using yfinance.
    
    Less comprehensive than Finviz but works without extra dependencies.
    """
    try:
        import yfinance as yf
        import pandas as pd
        
        # Start with our broad universe
        candidates = FALLBACK_UNIVERSE.copy()
        
        # Quick screen: download 1-month data for all at once
        logger.info("Quick-screening %d candidates via yfinance...", len(candidates))
        
        # Download in batch (much faster than individual calls)
        data = yf.download(candidates, period="1mo", auto_adjust=True, progress=False, threads=True)
        
        if data.empty:
            return candidates[:50]
        
        qualified = []
        closes = data["Close"] if "Close" in data.columns else data.get(("Close",), pd.DataFrame())
        
        for ticker in candidates:
            try:
                if ticker not in closes.columns:
                    continue
                prices = closes[ticker].dropna()
                if len(prices) < 5:
                    continue
                    
                current = float(prices.iloc[-1])
                month_low = float(prices.min())
                month_high = float(prices.max())
                
                # Quick filters: not crashed, showing strength
                if current > 0 and (current / month_high) > 0.90:  # Within 10% of month high
                    qualified.append(ticker)
            except Exception:
                continue
        
        logger.info("Quick screen qualified %d of %d candidates", len(qualified), len(candidates))
        return qualified if qualified else candidates[:50]
        
    except Exception as e:
        logger.warning("yfinance batch screen failed: %s", e)
        return FALLBACK_UNIVERSE[:50]


def get_screened_tickers(force_refresh: bool = False) -> list[str]:
    """Get pre-qualified tickers for full analysis.
    
    Strategy:
        1. Try Finviz screener (best: finds NEW opportunities)
        2. Fall back to yfinance batch screen (good: filters our universe)  
        3. Last resort: return full fallback universe
    
    Results are cached for 4 hours since screening is slow.
    
    Args:
        force_refresh: Bypass cache and re-screen
        
    Returns:
        List of ticker symbols to analyze (40-80 typically)
    """
    now = time.time()
    
    # Return cached if fresh
    if not force_refresh and _cache["tickers"] and (now - _cache["timestamp"]) < _cache["ttl"]:
        logger.info("Using cached screener results: %d tickers", len(_cache["tickers"]))
        return _cache["tickers"]
    
    logger.info("Running market screener...")
    
    # Try Finviz first
    tickers = _screen_finviz()
    
    # Fallback to yfinance batch
    if not tickers:
        tickers = _screen_yfinance_sp500()
    
    # Last resort
    if not tickers:
        tickers = FALLBACK_UNIVERSE[:50]
        logger.warning("All screeners failed, using fallback universe")
    
    # Cache results
    _cache["tickers"] = tickers
    _cache["timestamp"] = now
    
    logger.info("Screener ready: %d tickers to analyze", len(tickers))
    return tickers
