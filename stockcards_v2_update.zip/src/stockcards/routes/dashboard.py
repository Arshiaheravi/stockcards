"""
Dashboard route — the main data endpoint.

Serves the complete dashboard: signals + mood + news.
Uses the screener to find candidates across the whole market,
then runs full analysis in parallel for speed.
"""

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import Optional

import numpy as np
import yfinance as yf
from fastapi import APIRouter

from stockcards.config import get_settings
from stockcards.models.signals import DashboardData, StockSignal
from stockcards.services import analysis, signals
from stockcards.services.cache import cache_get, cache_set
from stockcards.services.market_mood import get_dual_market_mood
from stockcards.services.news import get_all_news
from stockcards.services.screener import get_screened_tickers
from stockcards.utils.helpers import clean_float

logger = logging.getLogger(__name__)
router = APIRouter()

# Shared SPY data (fetched once per scan, shared across all stocks)
_spy_cache: dict = {"prices": None, "timestamp": 0}


def _get_spy_prices() -> np.ndarray:
    """Fetch SPY data once and reuse for all RS calculations."""
    import time
    now = time.time()
    if _spy_cache["prices"] is not None and (now - _spy_cache["timestamp"]) < 300:
        return _spy_cache["prices"]
    
    try:
        spy = yf.Ticker("SPY")
        spy_df = spy.history(period="6mo", auto_adjust=True)
        if not spy_df.empty:
            _spy_cache["prices"] = spy_df["Close"].values
            _spy_cache["timestamp"] = now
            return _spy_cache["prices"]
    except Exception as e:
        logger.warning("SPY fetch failed: %s", e)
    
    return np.array([])


def analyze_stock(ticker: str, spy_prices: Optional[np.ndarray] = None) -> Optional[StockSignal]:
    """Full analysis pipeline for a single stock.

    Orchestrates:
    1. Check cache
    2. Fetch data from yfinance
    3. Run technical analysis
    4. Generate signal
    5. Package into StockSignal model
    """
    cache_key = f"stock:{ticker}"
    cached = cache_get(cache_key)
    if cached:
        return StockSignal(**cached)

    try:
        stock = yf.Ticker(ticker)
        df = stock.history(period="1y", auto_adjust=True)

        if df is None or df.empty or len(df) < 50:
            return None

        # Get name
        try:
            info = stock.info
            name = info.get("shortName") or info.get("longName") or ticker
        except Exception:
            name = ticker

        # Extract arrays
        closes = df["Close"].values
        highs = df["High"].values
        lows = df["Low"].values
        volumes = df["Volume"].values

        price = float(closes[-1])
        prev = float(closes[-2])
        change = ((price - prev) / prev) * 100

        # Technical analysis
        settings = get_settings()
        rsi = analysis.calculate_rsi(df["Close"])
        uptrend = analysis.check_uptrend(closes)
        pole_move = analysis.calculate_pole_move(highs, lows)
        flag_range = analysis.calculate_flag_range(highs, lows)
        has_flag = analysis.detect_flag_pattern(highs, lows, settings.pole_min, settings.flag_max_range)
        dist_ath = analysis.calculate_distance_from_ath(highs, price)
        near_ath = dist_ath <= settings.ath_proximity

        # Relative strength (use shared SPY data)
        if spy_prices is None or len(spy_prices) == 0:
            spy_prices = _get_spy_prices()
        relative_strength = analysis.calculate_relative_strength(closes, spy_prices)

        volume_surge, avg_volume, today_volume = analysis.check_volume_surge(volumes)
        stop_loss = analysis.calculate_stop_loss(lows)
        position_size = analysis.calculate_position_size(
            price, stop_loss, settings.portfolio_size, settings.risk_per_trade
        )

        # Generate signal
        signal, confidence = signals.generate_signal(
            rsi, has_flag, uptrend, near_ath, pole_move, flag_range,
            relative_strength, volume_surge,
        )
        details = signals.get_signal_details(
            signal, rsi, flag_range, pole_move, relative_strength, volume_surge,
        )

        logger.info("%s: %s (%d%%) RS:%.2f", ticker, signal, confidence, relative_strength)

        result = StockSignal(
            ticker=ticker,
            name=name[:30],
            price=round(clean_float(price), 2),
            change=round(clean_float(change), 2),
            signal=signal,
            confidence=confidence,
            rsi=clean_float(rsi, 50.0),
            distance_from_ath=clean_float(dist_ath, 100.0),
            pole_move=clean_float(pole_move),
            flag_range=clean_float(flag_range, 100.0),
            has_flag=has_flag,
            uptrend=uptrend,
            near_ath=near_ath,
            summary=details.summary,
            explanation=details.explanation,
            risk=details.risk,
            potential=details.potential,
            timeframe=details.timeframe,
            relative_strength=clean_float(relative_strength, 1.0),
            volume_surge=volume_surge,
            avg_volume=int(clean_float(avg_volume)),
            today_volume=int(clean_float(today_volume)),
            stop_loss=clean_float(stop_loss),
            position_size=int(clean_float(position_size)),
        )

        # Cache for 5 minutes
        cache_set(cache_key, result.model_dump(), 300)
        return result

    except Exception as e:
        logger.error("Error analyzing %s: %s", ticker, e)
        return None


@router.get("/api/dashboard", response_model=DashboardData)
async def dashboard(tickers: Optional[str] = None):
    """Full dashboard endpoint — signals, mood, and news.
    
    If no tickers specified, uses the screener to find candidates
    across the whole market, then analyzes them in parallel.
    """
    if tickers:
        ticker_list = [t.strip().upper() for t in tickers.split(",")]
    else:
        ticker_list = get_screened_tickers()

    logger.info("Scanning %d tickers...", len(ticker_list))

    # Fetch SPY once for all RS calculations
    spy_prices = _get_spy_prices()

    # Parallel analysis (10 threads — yfinance is I/O bound)
    stocks = []
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = {
            executor.submit(analyze_stock, t, spy_prices): t 
            for t in ticker_list
        }
        for future in as_completed(futures):
            result = future.result()
            if result:
                stocks.append(result)

    # Sort: BREAKOUT first, then BUY, READY, WATCH, WAIT, AVOID
    priority = {"BREAKOUT": 0, "BUY": 1, "READY": 2, "WATCH": 3, "WAIT": 4, "AVOID": 5}
    stocks.sort(key=lambda x: (priority.get(x.signal, 6), -x.confidence))

    logger.info("Found %d stocks (%d actionable)", 
                len(stocks), 
                sum(1 for s in stocks if s.signal in ("BREAKOUT", "BUY", "READY")))

    return DashboardData(
        market_mood=get_dual_market_mood(),
        stocks=stocks,
        news=get_all_news(),
        last_updated=datetime.now().isoformat(),
    )


@router.get("/api/stock/{ticker}")
async def get_single_stock(ticker: str):
    """Analyze a single stock on demand."""
    result = analyze_stock(ticker.upper())
    if not result:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail=f"Could not analyze {ticker}")
    return result


@router.get("/api/screener/refresh")
async def refresh_screener():
    """Force re-run the market screener."""
    tickers = get_screened_tickers(force_refresh=True)
    return {"status": "ok", "tickers": len(tickers), "sample": tickers[:20]}
